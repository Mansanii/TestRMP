package com.nsfas.student.portal.online;
import com.nsfas.student.portal.weblib.Wait;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class StudentOnlinePage {
    public static class Student {
        public static By checkBoxThirdParties = By.id("verify");
        public static By thirdPartyDescription = By.cssSelector("label.agree");
        public static By applicationIdNumber = By.id("idNumber");
        public static By infoPopUp = By.id("InfoMessageDiv");
        public static By warningBoxCloseButton = By.cssSelector("#informationBox > span");
        public static By applicationFirstName = By.id("firstnames");
        public static By applicationSureName = By.id("surname");
        public static By registerEmail = By.cssSelector("input#regemail");
        public static By registerConfirmEmail = By.id("regemailconfirm");
        public static By cellPhoneNumber = By.id("cellphone");
        public static By password = By.id("upass1");
        public static By confirmPassword = By.id("upass2");
        public static By uploadDocumentButton = By.cssSelector("div:nth-child(5) >div > button");
        public static By signInTab = By.id("loginTab");
        public static By cancelButton = By.id("cmd_cancelRegistration");
        public static By registerButton = By.cssSelector("input#cmd_register");
        public static By uploadDocumentInputFileField = By.cssSelector("ldiv:nth-child(5) > div > input.file-upload-input");
        public static By loginUserName = By.id("login_username");
        public static By loginPassword = By.id("login_password");
        public static By signInButton = By.id("cmdlogin");
        public static By forgotPasswordTab = By.id("cmd_reset");
        public static By verifyIdNumberField = By.id("verifyidNumber");
        public static By verifyProfileIdButton = By.id("cmd_verify_profile_id");
        public static By firstNameAndSurnameConditionsText = By.cssSelector("#nsfasProfileDiv > div:nth-child(5) > div");
        public static By termsAndConditions = By.cssSelector("#nsfasProfileDiv > div:nth-child(2) > label");
        public static By getThirdPartyDescriptionCheckBox = By.cssSelector("#nsfasProfileDiv > div.form-group.verifybox > label");
        // @FindBy (css = "#nsfasProfileDiv > div:nth-child(11) > div:nth-child(2) > ul > li" ) public List<WebElement> passwordConditionsLength;
        // public static List<WebElement> passwordConditionsLength = By.cssSelector("#nsfasProfileDiv > div:nth-child(11) > div:nth-child(2) > ul > li");
        public static By passwordConditionsList = By.cssSelector("#nsfasProfileDiv > div:nth-child(11) > div:nth-child(2) > ul > li");
        public static By passwordConditionsUpperCase = By.cssSelector("#nsfasProfileDiv > div:nth-child(11) > div:nth-child(2) > ul > li.uppercase");
        public static By passwordConditionsNumber = By.cssSelector("#nsfasProfileDiv > div:nth-child(11) > div:nth-child(2) > ul > li.number");
        public static By passwordConditionsSpecial = By.cssSelector("#nsfasProfileDiv > div:nth-child(11) > div:nth-child(2) > ul > li.special");



    }


}
