/*
package com.nsfas.student.portal.online;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.commons.GlobalVars;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;
import com.nsfas.student.portal.weblib.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.lang.reflect.Method;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Listeners(ExtentTestNGListener.class)
public class StudentOnlinePageTests extends Browser {

        @BeforeMethod(alwaysRun = true)
        public void beforeTestSetUp() throws Throwable {
            System.out.println("NSFAS Registration");
            ExtentTestNGListener.Report.log(Status.INFO, "NSFAS Registration");
            driver = Browser.getInstance().getDriver();
            Browser.getURL("http://10.15.64.23:8081/Application/selfservice.jsp#account2");
        }

        @Test(groups = {"Regression"})
        public void isStudentAbleToRegisterAtNSFASStudentOnlinePage() throws Throwable {
            //Assert.assertEquals(true, isDisplayedSignTab());
            clickOnRegisterButtonAndRegisterWithValidId();

        }

        @Test(groups = {"Regression"})
        public void shouldDisableAllFieldsIfStudentNotSelectedThirdPartyCheckBox() {

            StudentOnlinePage onlineStudentHomePage = new StudentOnlinePage();

            Verify.verifyElementVisible(onlineStudentHomePage.registerButton);
            Verify.verifyChecked(onlineStudentHomePage.checkBoxThirdParties);
            Verify.verifyElementVisible(onlineStudentHomePage.signInTab);
            Elements.getElementAttribute(onlineStudentHomePage.applicationIdNumber, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.applicationFirstName, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.applicationSureName, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.registerEmail, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.registerConfirmEmail, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.cellPhoneNumber, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.password, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.confirmPassword, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.registerButton, "disabled").equals("disabled");
        }

        @Test(groups = {"Regression"})
        public void isStudentAccessAllFieldsIfHeEntersWrongIDNumber() {

            StudentOnlinePage onlineStudentHomePage = new StudentOnlinePage();

            Verify.verifyElementVisible(onlineStudentHomePage.registerButton);
            Verify.verifyChecked(onlineStudentHomePage.checkBoxThirdParties);
            Elements.selectCheckbox(onlineStudentHomePage.checkBoxThirdParties);
            Elements.enterText(onlineStudentHomePage.applicationIdNumber, onlineStudentHomePage.INVALID_ID_NUMBER);
            Elements.getElementAttribute(onlineStudentHomePage.applicationFirstName, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.applicationSureName, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.registerEmail, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.registerConfirmEmail, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.cellPhoneNumber, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.password, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.confirmPassword, "disabled").equals("disabled");
            Elements.getElementAttribute(onlineStudentHomePage.registerButton, "disabled").equals("disabled");

        }

        @Test(groups = {"Regression"})
        public void validateTermsAnsConditionsTextOnStudentOnlinePage() throws Throwable {

            StudentOnlinePage onlineStudentHomePage = new StudentOnlinePage();

            List<String> ListOfPasswordConditionList = Arrays.asList("");

            Assert.assertEquals(true, Elements.getText(onlineStudentHomePage.termsAndConditions).equals("I understand and accept that if my application for" +
                    " financial aid is approved as eligible, funding is only confirmed and processed on receipt by NSFAS of valid registration" +
                    " costs from a public higher education institution for an approved funded programme. I accept that funding granted would be governed" +
                    " by the National Bursary Rules and Guidelines of the Department of Higher Education and Training which may be amended annually, and that" +
                    " I will comply with the annual requirements of funding. NSFAS will email a full NSFAS Bursary Agreement on receipt of valid registration data."));
            Assert.assertEquals(true, Elements.getText(onlineStudentHomePage.getThirdPartyDescriptionCheckBox).equals("I allow NSFAS to verify and validate the information I have provided with third parties."));

            Assert.assertEquals(true, Elements.getText(onlineStudentHomePage.firstNameAndSurnameConditionsText).equals("Please provide Firstnames and Surname as it is specified on the RSA ID or birth certificate."));


            Assert.assertEquals(true, onlineStudentHomePage.getApplicationIdNumberMaxLength().equals("13"));

        }
    }


    public boolean isDisplayedSignTab()  {

        return Wait.waitForElementPresence(StudentOnlinePage.Student.signInTab, GlobalVars.WAIT_SECONDS) ;
    }

    public void clickOnRegisterButtonAndRegisterWithValidId() throws Exception{

        DriverLib.click(StudentOnlinePage.Student.registerButton);
        DriverLib.selectCheckbox(StudentOnlinePage.Student.checkBoxThirdParties);
        DriverLib.inputText(StudentOnlinePage.Student.applicationIdNumber,GlobalVars.MTHAWULAHLWA_SURNAME);

        DriverLib.inputText(StudentOnlinePage.Student.applicationIdNumber,MTHAWULAHLWA_ID_NUMBER);


        Elements.clickButton(firstNameAndSurnameConditionsText);


        Elements.enterText(applicationFirstName,MTHAWULAHLWA_FIRSTNAME);

        Elements.enterText(applicationSureName,MTHAWULAHLWA_SURNAME);

        Elements.enterText(registerEmail,MTHAWULAHLWA_EMAIL);
        Elements.clickButton(warningBoxCloseButton);

        Elements.enterText(registerConfirmEmail,MTHAWULAHLWA_EMAIL);
        Elements.enterText(cellPhoneNumber,MTHAWULAHLWA_PHONE_NUMBER);

        Elements.enterText(password,MTHAWULAHLWA_PASSWORD);
        Elements.clickButton(warningBoxCloseButton);

        Elements.enterText(confirmPassword,MTHAWULAHLWA_PASSWORD);
        uploadFile("C:\\Users\\rakeshj\\Desktop\\picture.jpg");
        Elements.clickButton(registerButton);


    }

    public String getApplicationIdNumberMaxLength() {
        return Elements.getElementAttribute(applicationIdNumber, APPLICATION_ID_NUMBER_MAX_LENGTH);
    }


    public List<String> getTextDisplayedOnPasswordRules(By element) throws Throwable{
        List<String> textList = new ArrayList<>();
        try {
            for (WebElement passwordConditionList: passwordConditionsLength){
                String textDisplay = passwordConditionList.findElement(element).getText();
                textList.add(StringUtils.normalizeSpace(textDisplay));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return textList;
    }


    public static void setClipboardData(String string) throws InterruptedException {

        Thread.sleep(3000);
        WebElement textbox = driver.findElement(By.cssSelector("#nsfasProfileDiv > div:nth-child(11) > div:nth-child(5) > div > button"));
        ((JavascriptExecutor)driver).executeScript("arguments[0].click();", textbox);
        Thread.sleep(2000);
        StringSelection stringSelection = new StringSelection(string);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
    }

    public static void uploadFile(String fileLocation) {
        try {

            setClipboardData(fileLocation);

            Robot robot = new Robot();

            robot.setAutoDelay(2000);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.setAutoDelay(2000);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyRelease(KeyEvent.VK_V);
            robot.setAutoDelay(2000);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);

        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
}

}
*/
