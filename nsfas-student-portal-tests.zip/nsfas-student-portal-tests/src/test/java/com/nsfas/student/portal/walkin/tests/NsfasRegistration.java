package com.nsfas.student.portal.walkin.tests;

import com.nsfas.student.portal.utillib.CoreLib;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;
import com.nsfas.student.portal.weblib.*;
import com.nsfas.student.portal.walkin.locators.common.LoginLocators;
import com.nsfas.student.portal.weblib.Browser;
import org.testng.annotations.Listeners;
import org.testng.log4testng.Logger;


@Listeners(ExtentTestNGListener.class)
public class NsfasRegistration extends Browser {

    private static Logger logger=Logger.getLogger(NsfasRegistration.class);
    String userName = null;
    String firstName = null;
    String lastName = null;
    String emailAddress = null;
    @BeforeClass
    public void setUp()
    {

        String url = CoreLib.properties.getProperty("nsfasURl");
        System.out.println("URL==========="+url);
        CoreLib.ConfigFileReader("walkin//testdata//StudentsData.properties");
        String userName = CoreLib.properties.getProperty("userName");
        String firstName = CoreLib.properties.getProperty("firstName");
        String lastName = CoreLib.properties.getProperty("lastName");
        String emailAddress = CoreLib.properties.getProperty("emailAddress");
    }

    @Test
    public void login()  {
        System.out.println("NSFAS Registration");
        ExtentTestNGListener.Report.log(Status.INFO, "NSFAS Registration");
        driver = Browser.getInstance().getDriver();
        Browser.getURL("https://google.com");
        DriverLib.inputText(LoginLocators.Register.registerBtn,firstName);
        //Elements.clickButton(LoginLocators.Register.registerBtn);
        System.out.println("Test Method");
    }
}
