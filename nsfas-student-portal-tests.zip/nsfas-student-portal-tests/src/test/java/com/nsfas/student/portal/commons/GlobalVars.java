package com.nsfas.student.portal.commons;

public class GlobalVars {
    public static int WAIT_SECONDS = 20;
    public static String MTHAWULAHLWA_SURNAME = "NONQANE";
    public static String MTHAWULAHLWA_FIRSTNAME = "MTHAWULAHLWA HOPEWELL";
    public static String MTHAWULAHLWA_ID_NUMBER = "7904120741083";
    public static String MTHAWULAHLWA_PHONE_NUMBER = "713741920";
    public static String MTHAWULAHLWA_EMAIL = "csnonqane@gmail.com";
    public static String MTHAWULAHLWA_PASSWORD = "Nsfas@2021";
    public static String INVALID_ID_NUMBER = "7904120741";
    public static String APPLICATION_ID_NUMBER_MAX_LENGTH = "maxlength";
}
