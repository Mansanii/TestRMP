package com.nsfas.student.portal.utillib;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;
import com.nsfas.student.portal.weblib.DriverLib;
import org.testng.Assert;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

public class CoreLib {
    public static Properties properties;
    public static void createDir(String dirName) {
        File f = new File(dirName);
        try {
            if (!f.exists()) {
                f.mkdir();

                ExtentTestNGListener.Report.log(Status.INFO, "Directory Created :: " + dirName);
                System.out.println("Directory Created :: " + dirName);
            }
        } catch (Throwable e) {
            ExtentTestNGListener.Report.log(Status.ERROR, "Unable to create directory  '" +dirName + "'"+CoreLib.getMethodName());
            System.out.println("Unable to create directory  '" + dirName + "'");
        }
    }

    public static String getMethodName() {
        String methodName = null;
        try {
            return Thread.currentThread().getStackTrace()[2].getMethodName();
        } catch (Exception ioe) {
            ExtentTestNGListener.Report.log(Status.ERROR, "Exception at getMethodName():: " + ioe.getMessage());
            Assert.fail(CoreLib.getMethodName());

        }
        return methodName;
    }
    // Generates timestamp in the given format
    public static String generateTimeStamp() {
        String timeStamp = new SimpleDateFormat(" MMM d, yyyy hh_mm_ss").format(new Date());
        return timeStamp;
    }
    public static void ConfigFileReader(String propertyFilePath){
        BufferedReader reader;
        propertyFilePath = GlobalVars.Currentdir+GlobalVars.sourceDir+ File.separator+propertyFilePath;
        try {
            reader = new BufferedReader(new FileReader(propertyFilePath));
            properties = new Properties();
            try {
                properties.load(reader);
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
        }
    }
    public static void fileUpload(String filePath)
    {
        Robot rb = null;
        try {
            rb = new Robot();

        // copying File path to Clipboard
        StringSelection str = new StringSelection(filePath);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);

        // press Contol+V for pasting
        rb.keyPress(KeyEvent.VK_CONTROL);
        rb.keyPress(KeyEvent.VK_V);

        // release Contol+V for pasting
        rb.keyRelease(KeyEvent.VK_CONTROL);
        rb.keyRelease(KeyEvent.VK_V);

        // for pressing and releasing Enter
        rb.keyPress(KeyEvent.VK_ENTER);
        rb.keyRelease(KeyEvent.VK_ENTER);
        } catch (AWTException e) {
            DriverLib.logFailure("Failed at Method fileUpload() "+e.getMessage());
        }
    }
}
