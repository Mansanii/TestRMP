package com.nsfas.student.portal.utillib;

import java.nio.file.Path;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;

public class GlobalVars {
    public static WebDriver wdriver = null;
    public static String Currentdir = System.getProperty("user.dir");
    public static String ResultsDir = System.getProperty("user.dir");
    public static String sourceDir = "//src//test//java//com//nsfas//student//portal";
    public static String downloadPath = "";
    public static Path TakesScreenshotPath = null;
    public static String ScreenshotPath = null;
    public static String ScreeshotName = null;
    public static String SPACE = " ";
    public static HashMap<String, String> hMapVariableData = null;
    public static int waittime = 20;
    public static String errorMsg = "";
    public static String appErrorMsg = "";
}
