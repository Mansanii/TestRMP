package com.nsfas.student.portal.weblib;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.utillib.GlobalVars;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.util.List;
import java.util.logging.Logger;

public class Verify extends Browser{

    private static boolean bStatus;
    private static Logger logger= Logger.getLogger(Verify.class.getName());


    public static boolean verifyElementVisible(By objLocator)
    {
        try
        {
            bStatus = getInstance().getDriver().findElement(objLocator).isDisplayed();
            logger.info("Element "+objLocator+" is visible");
            return bStatus;
        }
        catch(Exception e)
        {
            GlobalVars.errorMsg =e.getMessage();
            logger.warning("Element "+objLocator+" is not visible.");
            return false;
        }
    }

    public static boolean verifyElementPresent(By objLocator)
    {
        try
        {
            getInstance().getDriver().findElement(objLocator);
            logger.info("Element "+objLocator+" is present in DOM");
            return true;
        }
        catch(Exception e)
        {
            GlobalVars.errorMsg =e.getMessage() ;
            logger.warning("Element "+objLocator+" is not present in DOM because "+GlobalVars.errorMsg);
            return false;
        }
    }

    public static boolean verifyTextVisible(String sText)
    {

        bStatus = getInstance().getDriver().getPageSource().contains(sText);
        if(bStatus)
        {
            logger.info("The Text "+sText+" is present in the current page ");
            ExtentTestNGListener.Report.log(Status.INFO,"The Text "+sText+" is present in the current page ");
            return true;
        }
        else
        {
            GlobalVars.errorMsg = sText+" not found in the current page";
            logger.warning(GlobalVars.errorMsg);
            ExtentTestNGListener.Report.log(Status.ERROR,GlobalVars.errorMsg);
            return false;
        }
    }

    public static boolean verifyTextVisible(By objLocator, String sText) throws Exception
    {
        //bStatus = verifyElementVisible(objLocator);
        WebElement element = null;
        element = DriverLib.waitForElement(objLocator);

        bStatus = element.getText().contains(sText);
        if(bStatus)
        {
            logger.info("The Text "+sText+" is present in the element "+objLocator+" because "+GlobalVars.errorMsg);
            ExtentTestNGListener.Report.log(Status.INFO,"The Text "+sText+" is present in the element ");
            return true;
        }
        else
            Asserts.assertFailure();
        GlobalVars.errorMsg = sText+" not found in the locator "+objLocator;
        logger.warning(GlobalVars.errorMsg);
        return false;
    }

    public static boolean verifyChecked(By objLocator)
    {
        bStatus = verifyElementVisible(objLocator);
        if(!bStatus)
        {
            logger.warning("The check box has cannot be checked because "+GlobalVars.errorMsg);
            return false;
        }
        bStatus = getInstance().getDriver().findElement(objLocator).isSelected();
        if(bStatus)
        {
            logger.info("The check box has already been selected");
            return true;
        }
        GlobalVars.errorMsg = objLocator+" is not selected";
        logger.warning(GlobalVars.errorMsg);
        return false;

    }

    public static boolean verifyFileExists(String sFileName)
    {
        File objFile = new File(sFileName);
        if (objFile.exists())
        {
            logger.info(sFileName+ "exist in directory");
            return true;
        }
        GlobalVars.errorMsg = sFileName+ " doesn't exist in directory";
        logger.warning(GlobalVars.errorMsg);
        return false;
    }

    public static boolean verifyItemPresent(By objLocator,String sItem)
    {
        bStatus = verifyElementVisible(objLocator);
        if(!bStatus)
        {
            logger.warning(sItem+" cannot be verified for the locator "+objLocator+" because "+GlobalVars.errorMsg);
            return false;
        }

        try
        {
            Select select = new Select(DriverLib.waitForElement(objLocator));
            List<WebElement> element = select.getOptions();
            for (int iCount = 0; iCount < element.size(); iCount++)
            {
                if(element.get(iCount).getText().equalsIgnoreCase(sItem))
                {
                    logger.info(sItem+" option is present in the element "+objLocator);
                    return true;
                }
            }
            GlobalVars.errorMsg = sItem+" option not found in the element "+objLocator;
            logger.warning(GlobalVars.errorMsg);
            return false;
        }
        catch(Exception e)
        {
            GlobalVars.errorMsg = e.getMessage();
            logger.warning(sItem+" item cannot be found because "+GlobalVars.errorMsg);
            return false;
        }
    }

    public static boolean verifyEnable(By objLocator)
    {
        bStatus = verifyElementPresent(objLocator);
        if(!bStatus)
        {
            logger.warning("Element "+objLocator+" is not visible "+GlobalVars.errorMsg);
            return false;
        }
        bStatus = getInstance().getDriver().findElement(objLocator).isEnabled();
        if(bStatus)
        {
            logger.info("The element is enabled");
            return true;
        }
        GlobalVars.errorMsg = objLocator+" is not enabled";
        logger.warning(GlobalVars.errorMsg);
        return false;
    }

    public static boolean verifyAlertPresent()
    {
        String alertMsg = Alerts.getAlertMessage();
        if(alertMsg == null)
        {
            logger.warning("No alert found");
            return false;
        }
        logger.info("Alert present");
        return true;
    }

    public static Boolean verifyElementsPresent(By objLocator)
    {
        try
        {
            getInstance().getDriver().findElements(objLocator);
            logger.info("The elements are prsent in the DOM");
            return true;
        } catch (NoSuchElementException e)
        {
            GlobalVars.errorMsg = e.getMessage();
            logger.warning("The elements are prsent in the DOM because "+GlobalVars.errorMsg);
            return false;
        }
    }
}



