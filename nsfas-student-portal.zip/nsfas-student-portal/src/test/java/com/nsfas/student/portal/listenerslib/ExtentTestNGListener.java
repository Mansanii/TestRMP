package com.nsfas.student.portal.listenerslib;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.weblib.Browser;
import com.nsfas.student.portal.reportlib.ExtentManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentTestNGListener extends Browser implements ITestListener{
        // Extent Report Declarations
        private static ExtentReports extent = ExtentManager.createInstance();
        public static ThreadLocal<ExtentTest> test = new ThreadLocal<>();
        public static ExtentTest Report = null;
        public static ExtentTest childReport = null;
        public static ExtentTest TempReport = null;

        @Override
        public synchronized void onStart(ITestContext context) {
            System.out.println("Extent Reports Version 3 Test Suite started!");
//		extentTest.log(Status.INFO,"Extent Reports Version 3 Test Suite started!");
            Report = extent.createTest(context.getName(),
                    context.getName());
            test.set(Report);
            Report.log(Status.INFO,(context.getName() + " started!"));
        }

        @Override
        public synchronized void onFinish(ITestContext context) {
            Report = TempReport;
            extent.flush();
        }

        @Override
        public synchronized void onTestStart(ITestResult result) {
            if(TempReport!=null)
                Report = TempReport;
            TempReport = Report;
            System.out.println((result.getMethod().getMethodName() + " started!"));
            childReport = Report.createNode(result.getMethod().getMethodName());
            Report = childReport;
            test.set(childReport);
        }

        @Override
        public synchronized void onTestSuccess(ITestResult result) {
            Report.log(Status.PASS,(result.getMethod().getMethodName() + " passed!"));
            test.get().pass("Test passed");
        }

        @Override
        public synchronized void onTestFailure(ITestResult result) {
            Report.log(Status.FAIL,(result.getMethod().getMethodName() + "On TEst failed!"));
            try {
                screenshot(result);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            test.get().fail(result.getMethod().getMethodName());
        }

        @Override
        public synchronized void onTestSkipped(ITestResult result) {
            Report.log(Status.SKIP,(result.getMethod().getMethodName() + " skipped!"));
            test.get().skip(result.getThrowable());
        }

        @Override
        public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
            Report.log(Status.FAIL,("onTestFailedButWithinSuccessPercentage for " + result.getMethod().getMethodName()));
        }
        public void screenshot(ITestResult tr) throws IOException{
            driver = Browser.getInstance().getDriver();
            File location = new File(System.getProperty("user.dir") + "/test-output");
            Date date = new Date();
            DateFormat format = new SimpleDateFormat("dd_MMM_yyyy__hh_mm_ssaa");
            String screenshotLoc = null;
            try {
                screenshotLoc = location.getCanonicalPath() + "/Screenshot/" + tr.getName() + format.format(date)+ ".png";
                File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                FileUtils.copyFile(src, new File(screenshotLoc));
            } catch (IOException e) {
                e.printStackTrace();
            }
            Reporter.log("<h4>Repro Steps--</h4><br>" + tr.getMethod().getDescription() + "<br>");
//		Report.log(Status.INFO,screenshotLoc);
            Report.addScreenCaptureFromPath(screenshotLoc);

        }
}
