package com.nsfas.student.portal.weblib;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.utillib.GlobalVars;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Iterator;
import java.util.Set;
import java.util.logging.Logger;

public class Wait extends Browser{
    public static WebDriver driver = null;
    private static WebDriverWait wait;
    private static boolean bStatus;
    private static Logger logger= Logger.getLogger(Wait.class.getName());

    Wait()
    {
        driver = Browser.getInstance().getDriver();
    }

    public static boolean waitForTextVisible(String sText,long iTimeout)
    {
        long iTimeoutinMillis = (iTimeout*10);
        long lFinalTime = System.currentTimeMillis() + iTimeoutinMillis;
        while(System.currentTimeMillis() < lFinalTime)
        {
            bStatus = Verify.verifyTextVisible(sText);
            if(bStatus)
            {
                logger.info("Text '"+sText+"' is present after waiting .");
                return true;
            }
        }
        GlobalVars.errorMsg="Text '"+sText+"' not found in the current page after waiting "+iTimeout+"secs";
        logger.warning(GlobalVars.errorMsg);
        return false;
    }

    public static boolean waitForTextVisible(By objLocator,String sText,long iTimeout)
    {
        long iTimeoutinMillis = (iTimeout*1000);
        long lFinalTime = System.currentTimeMillis() + iTimeoutinMillis;
        while(System.currentTimeMillis() < lFinalTime)
        {
            //	bStatus = Verify.verifyTextVisible(objLocator ,sText);
            if(bStatus)
            {
                logger.info("Text '"+sText+"' is present after waiting .");
                return true;
            }
        }
        GlobalVars.errorMsg="Text '"+sText+"' not found in the current page after waiting "+iTimeout+"secs";
        logger.warning(GlobalVars.errorMsg);
        return false;
    }

    public static boolean waitForAlert(long iTimeout)
    {
        long iTimeoutinMillis = (iTimeout*1000);
        long lFinalTime = System.currentTimeMillis() + iTimeoutinMillis;
        while(System.currentTimeMillis() < lFinalTime)
        {
            try {
                Browser.getInstance().getDriver().switchTo().alert();
                logger.info("Alert present");
                return true;
            } catch (NoAlertPresentException e) {
                GlobalVars.errorMsg = e.getMessage();
                continue;
            }
        }
        logger.warning(GlobalVars.errorMsg+" after waiting "+iTimeoutinMillis+" MilliSecs");
        ExtentTestNGListener.Report.log(Status.WARNING,GlobalVars.errorMsg+" after waiting "+iTimeoutinMillis+" MilliSecs");
        return false;
    }

	/*	public static boolean waitForAjax(long iTimeout)
	{
		long lFinalTime = System.currentTimeMillis() + iTimeout;
		JavascriptExecutor jsDriver = (JavascriptExecutor)Browser.getInstance().getDriver();
		while(System.currentTimeMillis() < lFinalTime) 
		{
			Object numberOfAjaxConnections = jsDriver.executeScript("return jQuery.active");
			Long n = (Long)numberOfAjaxConnections;
			if (n.longValue() == 0L)
				return true;
		}
		GlobalVars.errorMsg = "couldn't wait for Ajax to load completely";
		return false;

	}*/

    public static boolean waitForJQueryProcessing( long iTimeout)
    {
        boolean jQcondition = false;
        try{
            wait = new WebDriverWait(Browser.getInstance().getDriver(),iTimeout);
            wait.until(new ExpectedCondition<Boolean>()
            {
                @Override
                public Boolean apply(WebDriver driver)
                {
                    return (Boolean) ((JavascriptExecutor) Browser.getInstance().getDriver()).executeScript("return jQuery.active == 0");
                }

            });
            jQcondition = (Boolean) ((JavascriptExecutor) Browser.getInstance().getDriver()).executeScript("return window.jQuery != undefined && jQuery.active === 0");
            if(!jQcondition)
            {
                GlobalVars.errorMsg = "couldn't wait for Ajax to load completely after waiting "+iTimeout+"Secs";
                return false;
            }
            return true;
        }
        catch (Exception e)
        {
            GlobalVars.errorMsg = e.getMessage();
            return false;
        }
    }

    public static boolean waitForEnable(By objLocator,long iTimeout)
    {
        long iTimeoutinMillis = (iTimeout*1000);
        long lFinalTime = System.currentTimeMillis() + iTimeoutinMillis;
        while(System.currentTimeMillis() < lFinalTime)
        {
            bStatus = Verify.verifyEnable(objLocator);
            if(bStatus)
            {
                return true;
            }
        }
        GlobalVars.errorMsg = "TimedOut due to element is not enabled after "+iTimeout +"secs";
        return false;
    }

    public static boolean waitForWindow(long iTimeout)
    {
        String sMainHandler = Browser.getInstance().getDriver().getWindowHandle();
        System.out.println(sMainHandler);
        long iTimeoutinMillis = (iTimeout*1000);
        long lFinalTime = System.currentTimeMillis() + iTimeoutinMillis;
        while(System.currentTimeMillis() < lFinalTime)
        {
            Set<String> handlers = Browser.getInstance().getDriver().getWindowHandles();
            System.out.println("size of windows "+handlers);
            Iterator<String> winIterator = handlers.iterator();
            while (winIterator.hasNext())
            {
                String BancsChildWin = winIterator.next();
                System.out.println(BancsChildWin);
                if(!sMainHandler.equalsIgnoreCase(BancsChildWin))
                {
                    return true;
                }
            }
        }
        GlobalVars.errorMsg = "TimedOut due to new window is not availble after "+iTimeout +"secs";
        return false;
    }

    public static void waitUntilPageLoaded() throws InterruptedException {

        long timeOut = 30000;
        long end = System.currentTimeMillis() + timeOut;

        while (System.currentTimeMillis() <= end) {

            if (String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")).equals(
                    "complete")) {
                break;
            } else if (System.currentTimeMillis() == end) {
                ExtentTestNGListener.Report.log(Status.INFO,"....***......Page load not completed after ' " + timeOut / 1000 + " ' seconds.....");
            } else {
                ExtentTestNGListener.Report.log(Status.INFO,"...Page is still loading after ' " + timeOut / 1000 + " ' seconds.....");
            }
        }
    }
}


