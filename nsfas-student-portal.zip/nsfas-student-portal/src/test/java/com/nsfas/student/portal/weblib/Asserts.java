package com.nsfas.student.portal.weblib;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;
import org.testng.Assert;

public class Asserts {
    public static void assertFailure() throws Exception {
        ExtentTestNGListener.Report.log(Status.FAIL, "Failed Manually");
        Assert.fail("Sample Failure");
    }
}
