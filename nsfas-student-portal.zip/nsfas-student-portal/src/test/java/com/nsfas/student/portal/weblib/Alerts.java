package com.nsfas.student.portal.weblib;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.utillib.GlobalVars;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;

import java.util.logging.Logger;

public class Alerts extends Browser{

    private static boolean bStatus;
    private static Logger logger=Logger.getLogger(Alerts.class.getName());


    public static void test567()
    {
        logger.info("Alerts");
    }

    public static String getAlertMessage()
    {
        String alertMsg=null;
        bStatus = Wait.waitForAlert(5);
        if(bStatus)
        {
            alertMsg = Browser.getInstance().getDriver().switchTo().alert().getText();


            if(alertMsg != null)
            {
                logger.info("The text '"+alertMsg+"' from the alert has been retrieved successfully");
                ExtentTestNGListener.Report.log(Status.INFO,"The text '"+alertMsg+"' from the alert has been retrieved successfully");
                return alertMsg;
            }
            else
            {
                logger.warning("There is no text present in the alert");
                ExtentTestNGListener.Report.log(Status.ERROR,"There is no text present in the alert");
                return alertMsg;
            }
        }
        logger.warning("Cannot retrieve the message because "+ GlobalVars.errorMsg);
        return  alertMsg;
    }

    public static boolean acceptAlert()
    {
        bStatus = Verify.verifyAlertPresent();
        if(bStatus)
        {
            Browser.getInstance().getDriver().switchTo().alert().accept();
            return true;
        }
        logger.warning("The alert could not be consumed successfully because "+GlobalVars.errorMsg);
        ExtentTestNGListener.Report.log(Status.WARNING,"The alert could not be consumed successfully because "+GlobalVars.errorMsg);
        return false;

    }

    public static boolean closeAlert()
    {
        bStatus = Verify.verifyAlertPresent();
        if(bStatus)
        {
            Browser.getInstance().getDriver().switchTo().alert().dismiss();
            logger.info("The alert has been dismissed successfully");
            return true;
        }
        logger.warning("The alert dismissal has been unsuccessful because "+GlobalVars.errorMsg);
        ExtentTestNGListener.Report.log(Status.WARNING,"The alert dismissal has been unsuccessful because "+GlobalVars.errorMsg);
        return false;
    }

}

