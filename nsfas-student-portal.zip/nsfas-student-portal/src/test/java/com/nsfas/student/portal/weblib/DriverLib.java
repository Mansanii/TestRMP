package com.nsfas.student.portal.weblib;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;
import com.nsfas.student.portal.utillib.GlobalVars;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;
import java.util.Set;

public class DriverLib extends Browser {

    private static Actions act;
    public static WebElement ele = null;
    public static boolean acceptNextAlert = true;

    public static void inputText(By loc, String text) {
        try {
            waitUntilPageLoaded();
            ele = waitForElement(loc);
            ele.clear();
            ele.sendKeys(text);
        } catch (Exception e) {
            logFailure("Failed at Method: inputText() "+ e.getMessage()+" Locator: ",loc);
        }
    }

    public static void click(By loc) {
        try {
            waitUntilPageLoaded();
            ele = waitForElement(loc);
            ele.click();
        } catch (Exception e) {
            logFailure("Failed at Method: click() "+ e.getMessage()+" Locator: ",loc);
        }
    }

    public static void assertFailure() {
        try {
            ExtentTestNGListener.Report.log(Status.FAIL, "Failed Manually");
            Assert.fail("Sample Failure");
        } catch (Exception e) {
            logFailure("Failed at Method: assertFailure() "+ e.getMessage());
        }
    }

    public static void selectCheckbox(By loc) {
        try {
            waitUntilPageLoaded();
            ele = waitForElement(loc);
            boolean status = ele.isSelected();
            if (!status)
                ele.click();
        } catch (Exception e) {
            logFailure("Failed at Method: selectCheckbox "+ e.getMessage()+" Locator: ",loc);
        }
    }

    public static void unSelectCheckbox(By loc) {
        try {
            waitUntilPageLoaded();
            ele = waitForElement(loc);
            boolean status = ele.isSelected();
            if (status)
                ele.click();
        } catch (Exception e) {
            logFailure("Failed at Method: unSelectCheckbox() "+ e.getMessage()+" Locator: ",loc);
        }
    }

    public static void clearText(By loc) {
        try {
            waitUntilPageLoaded();
            ele = waitForElement(loc);
            ele.clear();
        } catch (Exception e) {
            logFailure("Failed at Method: clearText() "+ e.getMessage()+" Locator: ",loc);
        }
    }

    public static void selectOptionByIndex(By loc, int iIndexVal) {
        try {
            waitUntilPageLoaded();
            ele = waitForElement(loc);
            if (ele == null) {
                Select sel = new Select(ele);
                sel.selectByIndex(iIndexVal);
            }
        } catch (Exception e) {
            logFailure("Failed at Method: selectOptionByIndex() "+ e.getMessage()+" Locator: ",loc);
        }
    }

    public static void selectOptionByValue(By loc, String sValue) {
        try {
            waitUntilPageLoaded();
            ele = waitForElement(loc);
            if (ele == null) {
                Select sel = new Select(ele);
                sel.selectByValue(sValue);
            }
        } catch (Exception e) {
            logFailure("Failed at Method: selectOptionByValue() "+ e.getMessage()+" Locator: ",loc);
        }
    }

    public static String getElementAttribute(By loc, String sAttrVal) {
        String sValue = null;
        try {
            waitUntilPageLoaded();
            ele = waitForElement(loc);
            sValue = ele.getAttribute(sAttrVal);
        } catch (Exception e) {
            logFailure("Failed at Method: getElementAttribute() "+ e.getMessage()+" Locator: ",loc);
        }
        return sValue;
    }

    public static String getText(By loc) {
        String sValue = null;
        try {
            waitUntilPageLoaded();
            ele = waitForElement(loc);
            sValue = ele.getText();
        } catch (Exception e) {
            logFailure("Failed at Method: getText() "+ e.getMessage()+" Locator: ",loc);
        }
        return sValue;
    }

    public static String getAlertMessage() {
        String alertMsg = null;
        Alert alert = null;
        String alertText = null;
        try {
            Browser.getInstance().getDriver().switchTo().alert();
            alertText = alert.getText();
            if (acceptNextAlert) {
                alert.accept();
            } else {
                alert.dismiss();
            }
            acceptNextAlert = true;
        } catch (Exception e) {
            logFailure("Failed at Method: getAlertMessage() "+ e.getMessage());
        }
        return alertText;
    }


    public static WebElement waitForElement(By objLocator) {
        WebElement element = null;
        try {
            element = new WebDriverWait(Browser.getInstance().getDriver(), GlobalVars.waittime).ignoring(NoSuchElementException.class)
                    .ignoring(StaleElementReferenceException.class).until(ExpectedConditions.presenceOfElementLocated(objLocator));
            element = new WebDriverWait(Browser.getInstance().getDriver(), GlobalVars.waittime).ignoring(NoSuchElementException.class)
                    .ignoring(StaleElementReferenceException.class).until(ExpectedConditions.visibilityOf(element));
        } catch (Exception e) {
            logFailure("Failed at Method: waitForElement() "+ e.getMessage());
        }
        return element;
    }

    public static void waitUntilPageLoaded() {
        try {

            long timeOut = 30000;
            long end = System.currentTimeMillis() + timeOut;

            while (System.currentTimeMillis() <= end) {

                if (String.valueOf(((JavascriptExecutor) Browser.getInstance().getDriver()).executeScript("return document.readyState")).equals(
                        "complete")) {
                    break;
                } else if (System.currentTimeMillis() == end) {
                    ExtentTestNGListener.Report.log(Status.INFO, "....***......Page load not completed after ' " + timeOut / 1000 + " ' seconds.....");
                } else {
                    ExtentTestNGListener.Report.log(Status.INFO, "...Page is still loading after ' " + timeOut / 1000 + " ' seconds.....");
                }
            }
        } catch (Exception e) {
            logFailure("Failed at Method: waitUntilPageLoaded() "+ e.getMessage());
        }
    }

    public static void contextClick(By RClkLoc) {
        try {
            new Actions(Browser.getInstance().getDriver()).contextClick(waitForElement(RClkLoc)).build().perform();
        } catch (Exception e) {
            logFailure("Failed at Method: contextClick() "+ e.getMessage());
        }
    }
    public static void switchToFrame(By loc) throws Exception {
        try {
            Browser.getInstance().getDriver().switchTo().frame(waitForElement(loc));
            ExtentTestNGListener.Report.log(Status.INFO,"Switched to frame'" + loc + "'");
        } catch (NoSuchElementException nsee) {
            logFailure("Element  ' " + loc + " ' not found");

        } catch (Exception e) {
            logFailure("Error occured while Swithing from browser to  Frame ' " + loc + " '");
        }
    }


    public static void switchFromFrame() throws Exception {
        try {
            Browser.getInstance().getDriver().switchTo().defaultContent();
            ExtentTestNGListener.Report.log(Status.INFO,"Switched from frame");
        } catch (Exception e) {
            logFailure("Error occured while Swithing from frame to Browser ");
        }
    }
    public static void doubleClickElement(By elmtLocator) throws Exception {
        try {
            WebElement webElement = waitForElement(elmtLocator);
            Actions action = new Actions(Browser.getInstance().getDriver());
            action.moveToElement(webElement).doubleClick().build().perform();
            ExtentTestNGListener.Report.log(Status.INFO,"Double Clicked at the Locator '" + elmtLocator + "'");

        } catch (Exception e) {
            logFailure("Error occured while Double Click on the Element '" + elmtLocator + "'");
        }
    }
    public static void scrollTo(){
        String javascript = "window.scrollBy(0,500)";
        JavascriptExecutor jsExecutor = (JavascriptExecutor) Browser.getInstance().getDriver();
        jsExecutor.executeScript(javascript);
    }
    public static boolean dragAndDrop(By objLocatorSource,By objLocatorDestination)
    {
        WebElement wbElementSource = waitForElement(objLocatorSource);
        WebElement wbElementDestination = waitForElement(objLocatorDestination);
        if((wbElementSource == null)||(wbElementDestination == null))
        {
            ExtentTestNGListener.Report.log(Status.WARNING,"The drag and drop operation from (source) "+objLocatorSource+" to (target) "+objLocatorDestination+" could not be performed due to "+GlobalVars.errorMsg);
            return false;
        }
        act = new Actions(Browser.getInstance().getDriver());
        act.dragAndDrop(wbElementSource, wbElementDestination);
        act.perform();
        ExtentTestNGListener.Report.log(Status.INFO,"The drag and drop operation from (source) "+objLocatorSource+" to (target) "+objLocatorDestination+" has been performed succesfully.");
        return true;
    }












    public static void logFailure(String msg,By loc)
    {
        ExtentTestNGListener.Report.log(Status.ERROR,msg+loc);
        Assert.fail();
    }
    public static void logFailure(String msg)
    {
        ExtentTestNGListener.Report.log(Status.ERROR,msg);
        Assert.fail();
    }

}
