package com.nsfas.student.portal.weblib;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;
import com.nsfas.student.portal.utillib.GlobalVars;
import org.openqa.selenium.By;

import java.util.Iterator;
import java.util.Set;

public class Windows extends Browser{
    private static boolean bStatus;
    public static String getWindowTitle()
    {
        return Browser.getInstance().getDriver().getTitle();
    }

    public static String[] getWindowTitles()
    {
        Set<String> windows = Browser.getInstance().getDriver().getWindowHandles();
        int iSize = windows.size();
        String[] arrWindows = new String[iSize];
        int iInc = 0;
        for (String handle : windows)
        {
            Browser.getInstance().getDriver().switchTo().window(handle);
            arrWindows[iInc] = Browser.getInstance().getDriver().getTitle();
            iInc++;
        }
        return arrWindows;
    }
    public static boolean switchToWindowByIndex(int iWindowIndex)
    {
        Set<String> windows=Browser.getInstance().getDriver().getWindowHandles();
        Iterator itr=windows.iterator();
        int iSize=windows.size();
        if((iSize > 1))
        {
            if(iWindowIndex < iSize)
            {
                String[] arrWin =new String[iSize];
                int inc=0;
                while(itr.hasNext())
                {
                    arrWin[inc]=itr.next().toString();
                    inc++;
                }
                Browser.getInstance().getDriver().switchTo().window(arrWin[iWindowIndex]);
                return true;
            }
            GlobalVars.errorMsg = iWindowIndex+" is greater than windows count "+iSize;
            return false;
        }
        GlobalVars.errorMsg = "only one window is available";
        ExtentTestNGListener.Report.log(Status.INFO,GlobalVars.errorMsg);
        return false;
    }

    public static boolean switchToWindowByTitle(String sWindowName)
    {
        String sFocusedWindow = Browser.getInstance().getDriver().getWindowHandle();
        Set<String> windows = Browser.getInstance().getDriver().getWindowHandles();
        int iSize = windows.size();
        if(iSize >1)
        {
            for (String handle : windows)
            {
                Browser.getInstance().getDriver().switchTo().window(handle);
                if(Browser.getInstance().getDriver().getTitle().equalsIgnoreCase(sWindowName))
                {
                    return true;
                }
            }
            Browser.getInstance().getDriver().switchTo().window(sFocusedWindow);
            GlobalVars.errorMsg = sWindowName+" not found";
            return false;
        }
        GlobalVars.errorMsg = "only one window is available";
        return false;
    }

    public static boolean switchToFrameByFrameElement(By objLocator)
    {
        bStatus = Verify.verifyElementVisible(objLocator);
        if(bStatus)
        {
            Browser.getInstance().getDriver().switchTo().frame(Browser.getInstance().getDriver().findElement(objLocator));
            return true;
        }
        return false;
    }

    public static boolean switchToFrameByName(String sName)
    {
        By objLocator = By.name(sName);
        bStatus = Verify.verifyElementVisible(objLocator);
        if(bStatus)
        {
            try
            {
                Browser.getInstance().getDriver().switchTo().frame(sName);
                return true;
            }
            catch(Exception e)
            {
                GlobalVars.errorMsg = e.getMessage();
                ExtentTestNGListener.Report.log(Status.WARNING,GlobalVars.errorMsg);
                return false;
            }
        }
        return false;
    }

    public static boolean switchToFrameById(String sId)
    {
        By objLocator = By.id(sId);
        bStatus = Verify.verifyElementVisible(objLocator);
        if(bStatus)
        {
            try
            {
                Browser.getInstance().getDriver().switchTo().frame(sId);
                return true;
            }
            catch(Exception e)
            {
                GlobalVars.errorMsg = e.getMessage();
                ExtentTestNGListener.Report.log(Status.WARNING,GlobalVars.errorMsg);
                return false;
            }
        }
        return false;
    }

}

