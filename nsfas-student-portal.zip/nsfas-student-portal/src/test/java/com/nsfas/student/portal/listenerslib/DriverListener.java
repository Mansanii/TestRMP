package com.nsfas.student.portal.listenerslib;

import java.util.logging.Logger;

import com.nsfas.student.portal.weblib.Browser;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;

import com.aventstack.extentreports.Status;



public class DriverListener extends Browser implements WebDriverEventListener {

    private static String name;
    private static Logger logger=Logger.getLogger(DriverListener.class.getName());
    public static void setAlias (final String alias) {
        name = alias;
    }

    @Override
    public void afterAlertAccept (final WebDriver driver) {
    	logger.log(null, "Alert dialog accepted with message [{}]...",name);
    	ExtentTestNGListener.Report.log(Status.INFO, "Alert dialog accepted with message [{}]...");
    }

    @Override
    public void afterAlertDismiss (final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO, "Alert dialog dismissed [{}]...");
    }

    @Override
    public void afterChangeValueOf (final WebElement element, final WebDriver driver, final CharSequence[] keysToSend) {
        if (keysToSend != null) {
            final String message = "Text {} has been entered in element [{}]..."+keysToSend.toString();
            ExtentTestNGListener.Report.log(Status.INFO, "Text {} has been entered in element [{}]...");
        }
    }

    @Override
    public void afterClickOn (final WebElement element, final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Clicked on element [{}]...");
    }

    @Override
    public void afterFindBy (final By by, final WebElement element, final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Element [{}] found using {}..."+ by);
    }

    @Override
    public <X> void afterGetScreenshotAs (final OutputType<X> target, final X screenshot) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Taken screenshot successfully...");
    }

    @Override
    public void afterGetText (final WebElement element, final WebDriver driver, final String text) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Got text {} from element [{}]..."+ text);
    }

    @Override
    public void afterNavigateBack (final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Navigated backward...");
    }

    @Override
    public void afterNavigateForward (final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Navigated forward...");
    }

    @Override
    public void afterNavigateRefresh (final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Page refreshed...");
    }

    @Override
    public void afterNavigateTo (final String url, final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Navigated to url {}..."+ url);
    }

    @Override
    public void afterScript (final String script, final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Script {} executed successfully..."+script);
    }

    @Override
    public void afterSwitchToWindow (final String windowName, final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Window switched to {}..."+ windowName);
    }

    @Override
    public void beforeAlertAccept (final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Accepting Alert pop-up with message [{}]...");
    }

    @Override
    public void beforeAlertDismiss (final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Dismissing Alert pop-up with message [{}]...");
    }

    @Override
    public void beforeChangeValueOf (final WebElement element, final WebDriver driver,
        final CharSequence[] keysToSend) {
		/*
		 * if (keysToSend != null) { ExtentTestNGListener.Report.log(Status.
		 * INFO,"Writing text {} in element [{}]..."+ keysToSend + " "+ name); }
		 */
    }

    @Override
    public void beforeClickOn (final WebElement element, final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Clicking on element [{}]...");
    }

    @Override
    public void beforeFindBy (final By by, final WebElement element, final WebDriver driver) {
//    	ExtentTestNGListener.Report.log(Status.INFO,"Finding element [{}] using {}"+ name+ " "+ by);
    }

    @Override
    public <X> void beforeGetScreenshotAs (final OutputType<X> target) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Taking screenshot...");
    }

    @Override
    public void beforeGetText (final WebElement element, final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Getting text from element [{}]..."+name);
    }

    @Override
    public void beforeNavigateBack (final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Navigating back...");
    }

    @Override
    public void beforeNavigateForward (final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Navigating forward...");
    }

    @Override
    public void beforeNavigateRefresh (final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Refreshing the page...");
    }

    @Override
    public void beforeNavigateTo (final String url, final WebDriver driver) {
//    	ExtentTestNGListener.Report.log(Status.INFO,"Navigating to {}..."+ url);
    }

    @Override
    public void beforeScript (final String script, final WebDriver driver) {
        final String message = "Executing script {}...";
        ExtentTestNGListener.Report.log(Status.INFO,message + " "+ script);
    }

    @Override
    public void beforeSwitchToWindow (final String windowName, final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.INFO,"Switching to window {}..."+windowName);
    }

    @Override
    public void onException (final Throwable throwable, final WebDriver driver) {
    	ExtentTestNGListener.Report.log(Status.ERROR,throwable);
    	ExtentTestNGListener.Report.log(Status.ERROR,"Error occurred: {}"+ throwable.getMessage().toString());
//    	ExtentTestNGListener.Report.log(Status.ERROR,throwable.getStackTrace ()).forEach (s -> LOG.e ("\tat: {}", s));
    }
    
    
}