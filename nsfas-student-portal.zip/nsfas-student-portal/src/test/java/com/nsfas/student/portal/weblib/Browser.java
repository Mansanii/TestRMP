package com.nsfas.student.portal.weblib;

import com.aventstack.extentreports.Status;
import com.nsfas.student.portal.listenerslib.DriverListener;
import com.nsfas.student.portal.listenerslib.ExtentTestNGListener;
import com.nsfas.student.portal.utillib.CoreLib;
import com.nsfas.student.portal.utillib.GlobalVars;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class Browser {
    public static WebDriver driver;
    public WebDriverWait wait;
    public  static EventFiringWebDriver e_driver;
    public static DriverListener eventListener;

    public WebDriver getDriver() {
        return driver;
    }

    @BeforeClass(alwaysRun=true)
    public WebDriver setup () {
        CoreLib.ConfigFileReader("config//Configuration.properties");
        String browserType = CoreLib.properties.getProperty("browserType");
        try {
            if (GlobalVars.wdriver == null) {
                switch (browserType) {
                    case "FF":
                        openFirefoxBrowser();
                        break;
                    case "GC": {
                        openChromeBrowser();
                        break;
                    }
                    case "IE": {
                        openIEBrowser();
                        break;
                    }
                    default: {
                        ExtentTestNGListener.Report.log(Status.INFO, "Please Check Browser Type");
                    }
                }
                ExtentTestNGListener.Report.log(Status.INFO, browserType + "' Browser Lanched Successfully ");
                driver.manage().window().maximize();
/*                e_driver = new EventFiringWebDriver(driver);
                // Now create object of EventListerHandler to register it with EventFiringWebDriver
                eventListener = new DriverListener();
                e_driver.register(eventListener);
                driver = e_driver;*/
            }
        } catch (Exception e) {
            ExtentTestNGListener.Report.log(Status.INFO,
                    "Error occured while lanching the Browser ::'" + browserType + "'" + e.getMessage());
        }
        return driver;
    }
    private static void openFirefoxBrowser() {
        WebDriverManager.firefoxdriver().setup();
        FirefoxProfile profile = new FirefoxProfile();
        DesiredCapabilities dc = DesiredCapabilities.firefox();
        profile.setPreference("intl.accept_languages", "en-gb");
        profile.setPreference("browser.download.folderList", 2);
        profile.setPreference("browser.download.dir", GlobalVars.downloadPath);
        profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
        profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
                "application/msword, application/csv, application/ris, text/csv, "
                        + "image/png, application/pdf, text/html, text/plain, application/zip, application/x-zip, "
                        + "application/x-zip-compressed, application/download, application/octet-stream");
        dc.setCapability(FirefoxDriver.PROFILE, profile);
        driver = new FirefoxDriver();

    }

    private static void openChromeBrowser() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("start-maximized");
        options.addArguments("enable-automation");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-infobars");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-browser-side-navigation");
        options.addArguments("--disable-gpu");
        driver = new ChromeDriver(options);
    }



    private static void openIEBrowser() {
        WebDriverManager.iedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("start-maximized");
        options.addArguments("enable-automation");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-infobars");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-browser-side-navigation");
        options.addArguments("--disable-gpu");
        driver = new InternetExplorerDriver();
    }

    @AfterClass(alwaysRun=true)
    public static void afterClass()
    {
        try{
            driver.close();
        }
        catch (Exception e) {
            ExtentTestNGListener.Report.log(Status.ERROR,"Exception in afterClass: "+e.getMessage());
        }
    }
    private static Browser base = null;

    public static Browser getInstance() {
        if (base == null) {
            base = new Browser();
        }
        return base;
    }

    public static void getURL(String url)
    {
        try {
            Browser.getInstance().getDriver().navigate().to(url);
        }
        catch (Exception e)
        {
            ExtentTestNGListener.Report.log(Status.ERROR,"Exception in getURL: "+e.getMessage());
        }

    }
}
